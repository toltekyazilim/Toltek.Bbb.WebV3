"use strict";
!function () {
    document.getElementsByTagName("body")[0].setAttribute("data-pc-layout", "tab");
    document.querySelector(".pc-navbar").innerHTML;
    for (var r, c, o, l, i, d = document.querySelector(".tab-container > .tab-sidemenu > .pc-tab-link"), b = document.querySelector(".tab-container > .tab-link > .navbar-content > .tab-content"), e = (document.querySelector(".tab-container > .tab-sidemenu") && new SimpleBar(document.querySelector(".tab-container > .tab-sidemenu")),
        document.querySelector(".tab-container > .tab-link .navbar-content") && new SimpleBar(document.querySelector(".tab-container > .tab-link .navbar-content")),
        document.querySelectorAll(".pc-navbar li .pc-submenu")), t = 0; t < e.length; t++)
        e[t].style.display = "none";
    r = document.querySelectorAll(".pc-navbar > li.pc-item"),
        o = 0,
        l = !1,
        i = c = "",
        r.forEach(function (t, e) {
            if (t.classList.contains("pc-caption")) {
                if (d) {
                    o += 1;
                    var a = "";
                    try {
                        a = t.children[1].outerHTML
                    } catch (e) {
                        a = t.children[0].innerHTML.charAt(0)
                    }
                    d.insertAdjacentHTML("beforeend", '<li class="nav-item" data-bs-toggle="tooltip" title="' + t.children[0].innerHTML + '"><a class="nav-link" id="pc-tab-link-' + o + '" data-bs-target="#pc-tab-' + o + '" role="tab" data-bs-toggle="tab" aria-controls="home-tab-pane"            "data-bs-placement="right">' + a + "</a></li>")
                }
                !0 === l && b && (0 == (n = o - 1) && (i = c),
                    1 == n && (c = i += c,
                        i = ""),
                    b.insertAdjacentHTML("beforeend", '<div class="tab-pane fade" id="pc-tab-' + n + '" role="tabpanel" aria-labelledby="pc-tab-link-' + n + '" tabindex="' + n + '"><ul class="pc-navbar">              ' + c + "              </ul></div>"),
                    c = ""),
                    t.remove()
            } else {
                var n;
                c += t.outerHTML,
                    l = !0,
                    t.remove(),
                    e + 1 === r.length && b && (n = o,
                        b.insertAdjacentHTML("beforeend", '<div class="tab-pane fade" id="pc-tab-' + n + '" role="tabpanel" aria-labelledby="pc-tab-link-' + n + '" tabindex="' + n + '"><ul class="pc-navbar">              ' + c + "              </ul></div>"),
                        c = "")
            }
        });
    for (var a = document.querySelectorAll(".pc-sidebar .pc-navbar a"), n = 0; n < a.length; n++) {
        var s = window.location.href.split(/[?#]/)[0];
        if (a[n].href == s && "" != a[n].getAttribute("href")) {
            a[n].parentNode.classList.add("active"),
                a[n].parentNode.parentNode.parentNode.classList.add("pc-trigger"),
                a[n].parentNode.parentNode.parentNode.classList.add("active"),
                a[n].parentNode.parentNode.style.display = "block",
                a[n].parentNode.parentNode.parentNode.parentNode.parentNode.classList.add("pc-trigger"),
                a[n].parentNode.parentNode.parentNode.parentNode.style.display = "block";
            for (var p, u = !0, m = a[n]; u;)
                (m = m.parentNode).classList.contains("tab-pane") && (p = m.getAttribute("id"),
                    p = document.querySelector('.tab-sidemenu a[data-bs-target="#' + p + '"]'),
                    new bootstrap.Tab(p).show(),
                    u = !1)
        }
    }
    menu_click()
}();
