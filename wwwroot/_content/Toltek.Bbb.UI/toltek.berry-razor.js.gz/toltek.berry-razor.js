window.toggleSidebar = function () {
    document.body.classList.toggle('pc-sidebar-collapse');
};

window.toggleMobileSidebar = function () {
    document.body.classList.toggle('pc-sidebar-open');
};